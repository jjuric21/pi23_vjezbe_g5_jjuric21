﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Evaluation_Manager_DS.Models {
    public class Student : Person {
        public int Grade { get; set; }
    }
}
